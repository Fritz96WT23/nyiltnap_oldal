<?php
declare(strict_types=1);
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_set_cookie_params([
        'httponly' => true,
        'samesite' => 'Lax',
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    ]);
    session_start();
}
require __DIR__ . '/../app/Database.php';
require __DIR__ . '/../app/Models/Registration.php';
require __DIR__ . '/../app/Controllers/RegistrationController.php';
require __DIR__ . '/../app/Controllers/AdminController.php';

function biztonsagosSzoveg(mixed $ertek): string { return htmlspecialchars((string)$ertek, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function csrf_jegy(): string { if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function csrf_ervenyes(mixed $jegy): bool { return is_string($jegy) && isset($_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $jegy); }
function adminSzukseges(): void { if (empty($_SESSION['admin'])) { header('Location: index.php?page=admin-login'); exit; } }

try {
    $modell = new Registration(Database::connect());
    $jelentkezesVezerlo = new RegistrationController($modell);
    $adminVezerlo = new AdminController($modell);
    $oldal = (string)($_GET['page'] ?? 'register');
    switch ($oldal) {
        case 'register':
            if ($_SERVER['REQUEST_METHOD'] === 'POST') $jelentkezesVezerlo->store();
            else $jelentkezesVezerlo->index();
            break;
        case 'admin-login': $adminVezerlo->login(); break;
        case 'admin': $adminVezerlo->dashboard(); break;
        case 'logout':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit('Nem engedélyezett metódus.'); }
            $adminVezerlo->logout(); break;
        default: http_response_code(404); echo 'Az oldal nem található.';
    }
} catch (PDOException $kivetel) {
    http_response_code(500);
    echo '<!doctype html><html lang="hu"><meta charset="utf-8"><title>Adatbázis hiba</title><body style="font-family:sans-serif;padding:2rem"><h1>Nem sikerült kapcsolódni az adatbázishoz.</h1><p>Ellenőrizd a <code>config/config.php</code> beállításait, és importáld a <code>database/schema.sql</code> fájlt phpMyAdminban.</p></body></html>';
}
