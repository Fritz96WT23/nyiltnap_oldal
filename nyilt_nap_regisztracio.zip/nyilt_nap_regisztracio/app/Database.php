<?php
declare(strict_types=1);

final class Database
{
    public static function connect(): PDO
    {
        static $kapcsolat = null;
        if ($kapcsolat instanceof PDO) return $kapcsolat;
        $beallitasok = require __DIR__ . '/../config/config.php';
        $adatbazisBeallitasok = $beallitasok['adatbazis'];
        $kapcsolatiKarakterlanc = "mysql:host={$adatbazisBeallitasok['kiszolgalo']};dbname={$adatbazisBeallitasok['adatbazis_neve']};charset={$adatbazisBeallitasok['karakterkeszlet']}";
        $kapcsolat = new PDO($kapcsolatiKarakterlanc, $adatbazisBeallitasok['felhasznalo'], $adatbazisBeallitasok['jelszo'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
        return $kapcsolat;
    }
}
