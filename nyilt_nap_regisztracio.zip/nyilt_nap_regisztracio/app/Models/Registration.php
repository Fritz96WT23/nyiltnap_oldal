<?php
declare(strict_types=1);

class Registration
{
    public function __construct(private PDO $adatbazis) {}

    public function aktivSzakok(): array
    {
        return $this->adatbazis->query('SELECT id, nev FROM szakok WHERE aktiv = 1 ORDER BY nev')->fetchAll();
    }

    public function letrehoz(array $adatok, array $szakAzonositok): int
    {
        $this->adatbazis->beginTransaction();
        try {
            $utasitas = $this->adatbazis->prepare('INSERT INTO jelentkezesek (teljes_nev, iskola_neve, lakhatasi_forma, vegzos) VALUES (?, ?, ?, ?)');
            $utasitas->execute([$adatok['teljes_nev'], $adatok['iskola_neve'], $adatok['lakhatasi_forma'], $adatok['vegzos']]);
            $jelentkezesAzonosito = (int)$this->adatbazis->lastInsertId();
            $kapcsolat = $this->adatbazis->prepare('INSERT INTO jelentkezes_szakok (jelentkezes_id, szak_id) SELECT ?, id FROM szakok WHERE aktiv = 1 AND id = ?');
            foreach ($szakAzonositok as $szakAzonosito) {
                $kapcsolat->execute([$jelentkezesAzonosito, $szakAzonosito]);
            }
            $this->adatbazis->commit();
            return $jelentkezesAzonosito;
        } catch (Throwable $hiba) {
            $this->adatbazis->rollBack();
            throw $hiba;
        }
    }

    public function osszesJelentkezes(): array
    {
        $lekerdezes = "SELECT j.id, j.teljes_nev, j.iskola_neve, j.lakhatasi_forma, j.vegzos, j.letrehozva,
                       GROUP_CONCAT(sz.nev ORDER BY sz.nev SEPARATOR ', ') AS szak_nevek
                FROM jelentkezesek j
                LEFT JOIN jelentkezes_szakok jsz ON jsz.jelentkezes_id = j.id
                LEFT JOIN szakok sz ON sz.id = jsz.szak_id
                GROUP BY j.id ORDER BY j.letrehozva DESC, j.id DESC";
        return $this->adatbazis->query($lekerdezes)->fetchAll();
    }

    public function statisztikak(): array
    {
        $szakLekerdezes = "SELECT sz.id, sz.nev,
            COUNT(DISTINCT jsz.jelentkezes_id) AS osszes,
            COUNT(DISTINCT CASE WHEN j.vegzos = 1 THEN j.id END) AS vegzosok,
            COUNT(DISTINCT CASE WHEN j.lakhatasi_forma = 'koleszos' THEN j.id END) AS koleszosok,
            COUNT(DISTINCT CASE WHEN j.lakhatasi_forma = 'koleszos' AND j.vegzos = 1 THEN j.id END) AS koleszos_vegzosok
            FROM szakok sz LEFT JOIN jelentkezes_szakok jsz ON jsz.szak_id = sz.id
            LEFT JOIN jelentkezesek j ON j.id = jsz.jelentkezes_id
            WHERE sz.aktiv = 1 GROUP BY sz.id, sz.nev ORDER BY osszes DESC, sz.nev";
        $osszesito = $this->adatbazis->query("SELECT COUNT(*) AS osszes,
            COALESCE(SUM(vegzos = 1), 0) AS vegzosok,
            COALESCE(SUM(lakhatasi_forma = 'koleszos'), 0) AS koleszosok,
            COALESCE(SUM(lakhatasi_forma = 'koleszos' AND vegzos = 1), 0) AS koleszos_vegzosok
            FROM jelentkezesek")->fetch();
        return ['szakok' => $this->adatbazis->query($szakLekerdezes)->fetchAll(), 'osszesito' => $osszesito];
    }

    public function torol(int $azonosito): void
    {
        $utasitas = $this->adatbazis->prepare('DELETE FROM jelentkezesek WHERE id = ?');
        $utasitas->execute([$azonosito]);
    }
}
