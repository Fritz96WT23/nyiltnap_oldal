<!doctype html>
<html lang="hu">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Nyílt nap | Regisztráció</title><link rel="stylesheet" href="assets/style.css">
</head>
<body class="public-page">
<header class="topbar"><a class="brand" href="index.php" aria-label="Nyílt nap kezdőlap"><img class="school-logo" src="assets/iskola_logo.png" alt="Az iskola logója"><span class="brand-copy"><strong>Nádasdy Tamás Technikum és Kollégium</strong><small>NYÍLT NAP<br>Ismerd meg a jövőd!</small></span></a><span class="top-pill"><span class="pulse"></span> REGISZTRÁCIÓ</span></header>
<main class="hero-wrap">
  <section class="intro"><div class="eyebrow"><span></span> A KÖVETKEZŐ LÉPÉS ITT KEZDŐDIK</div><h1>Találd meg a<br><em>saját utad.</em></h1><p class="intro-text">Regisztrálj nyílt napunkra, ismerd meg képzéseinket, és tedd fel a kérdéseidet személyesen!</p>
    <div class="feature-list"><div class="feature"><span class="feature-icon">01</span><span><b>Fedezd fel a szakmákat</b><small>Jelölj meg akár több képzést is.</small></span></div><div class="feature"><span class="feature-icon">02</span><span><b>Ismerd meg az iskolát</b><small>Valódi élmények, hasznos válaszok.</small></span></div></div>
    <div class="orbit orbit-one"></div><div class="orbit orbit-two"></div>
  </section>
  <section class="form-panel"><div class="form-heading"><div><span class="section-tag">JELENTKEZÉS</span><h2>Regisztráció</h2><p>Pár adat, és már várunk is!</p></div><div class="step-mark">01 <span>/ 01</span></div></div>
    <?php if (!empty($hibak)): ?><div class="alert error"><strong>Nézd át a megadott adatokat!</strong><ul><?php foreach ($hibak as $hiba): ?><li><?= biztonsagosSzoveg($hiba) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
    <?php if (isset($_GET['success'])): ?><div class="alert success"><strong>Sikeres regisztráció!</strong><br>Köszönjük, az adataidat elmentettük. Várunk a nyílt napon!</div><?php endif; ?>
    <form method="post" action="index.php" class="registration-form">
      <input type="hidden" name="csrf" value="<?= biztonsagosSzoveg(csrf_jegy()) ?>">
      <label class="field"><span>Teljes név <i>*</i></span><input type="text" name="teljes_nev" maxlength="160" placeholder="Pl. Kovács Anna" autocomplete="name" required></label>
      <label class="field"><span>Iskola, ahonnan érkezel <i>*</i></span><input type="text" name="iskola_neve" maxlength="200" placeholder="A jelenlegi iskolád neve" required></label>
      <fieldset class="trade-field"><legend> Melyik szakma érdekel? <i>*</i> <small>Többet is megjelölhetsz</small></legend><div class="trade-grid">
        <?php foreach ($szakok as $szak): ?><label class="trade-option"><input type="checkbox" name="szakok[]" value="<?= (int)$szak['id'] ?>"><span class="check-box">✓</span><span><?= biztonsagosSzoveg($szak['nev']) ?></span></label><?php endforeach; ?>
      </div></fieldset>
      <fieldset class="choice-field"><legend>Hol laknál tanulóként? <i>*</i></legend><div class="choice-row"><label class="choice-card"><input type="radio" name="lakhatasi_forma" value="koleszos" required><span class="radio-dot"></span><span><b>Kollégista</b><small>Kollégiumban laknék</small></span><span class="choice-symbol">⌂</span></label><label class="choice-card"><input type="radio" name="lakhatasi_forma" value="bejaro" required><span class="radio-dot"></span><span><b>Bejárós</b><small>Naponta bejárnék</small></span><span class="choice-symbol">↗</span></label></div></fieldset>
      <label class="graduate-option"><input type="checkbox" name="vegzos" value="1"><span class="check-box">✓</span><span><b>Végzős vagyok</b><small>Jelenleg végzős évfolyamba járok.</small></span></label>
      <button class="submit-button" type="submit"><span>Regisztráció elküldése</span><span class="arrow">↗</span></button><p class="privacy-note"><span>◆</span> Az adataidat kizárólag a nyílt nap szervezéséhez használjuk.</p>
    </form>
  </section>
</main><footer class="site-footer"><span>© Nyílt nap · Várunk szeretettel!</span><a href="index.php?page=admin-login">Admin belépés</a></footer>
</body></html>
