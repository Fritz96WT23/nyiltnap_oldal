<?php
declare(strict_types=1);

class RegistrationController
{
    public function __construct(private Registration $modell) {}

    public function index(): void
    {
        $szakok = $this->modell->aktivSzakok();
        $hibak = $_SESSION['hibak'] ?? [];
        unset($_SESSION['hibak']);
        require __DIR__ . '/../Views/register.php';
    }

    private static function karakterHossz(string $szoveg): int
    {
        if (function_exists('mb_strlen')) {
            return mb_strlen($szoveg, 'UTF-8');
        }
        $talalatok = preg_match_all('/./us', $szoveg);
        return $talalatok === false ? strlen($szoveg) : $talalatok;
    }

    public function store(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !csrf_ervenyes($_POST['csrf'] ?? '')) {
            http_response_code(400); exit('Érvénytelen kérés. Frissítsd az oldalt, majd próbáld újra.');
        }
        $teljesNev = trim((string)($_POST['teljes_nev'] ?? ''));
        $iskolaNeve = trim((string)($_POST['iskola_neve'] ?? ''));
        $lakhatasiForma = (string)($_POST['lakhatasi_forma'] ?? '');
        $vegzos = isset($_POST['vegzos']) && $_POST['vegzos'] === '1' ? 1 : 0;
        $szakAzonositok = array_values(array_unique(array_filter(array_map('intval', (array)($_POST['szakok'] ?? [])), fn($szam) => $szam > 0)));
        $hibak = [];
        if ($teljesNev === '' || self::karakterHossz($teljesNev) > 160) $hibak[] = 'Add meg a teljes neved (legfeljebb 160 karakter).';
        if ($iskolaNeve === '' || self::karakterHossz($iskolaNeve) > 200) $hibak[] = 'Add meg az iskolád nevét (legfeljebb 200 karakter).';
        if (!in_array($lakhatasiForma, ['koleszos', 'bejaro'], true)) $hibak[] = 'Válaszd ki, kollégista vagy bejárós lennél-e.';
        $ervenyesAzonositok = array_map('intval', array_column($this->modell->aktivSzakok(), 'id'));
        if (!$szakAzonositok || array_diff($szakAzonositok, $ervenyesAzonositok)) $hibak[] = 'Válassz legalább egy érdeklődési szakot.';
        if ($hibak) {
            $_SESSION['hibak'] = $hibak;
            header('Location: index.php'); exit;
        }
        $this->modell->letrehoz(['teljes_nev' => $teljesNev, 'iskola_neve' => $iskolaNeve, 'lakhatasi_forma' => $lakhatasiForma, 'vegzos' => $vegzos], $szakAzonositok);
        header('Location: index.php?success=1'); exit;
    }
}
