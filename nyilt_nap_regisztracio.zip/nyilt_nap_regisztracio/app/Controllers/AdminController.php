<?php
declare(strict_types=1);

class AdminController
{
    public function __construct(private Registration $modell) {}

    public function login(): void
    {
        $hibaUzenet = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!csrf_ervenyes($_POST['csrf'] ?? '')) { $hibaUzenet = 'Érvénytelen kérés. Frissítsd az oldalt.'; }
            else {
                $beallitasok = require __DIR__ . '/../../config/config.php';
                $felhasznalonev = (string)($_POST['felhasznalonev'] ?? '');
                $jelszo = (string)($_POST['jelszo'] ?? '');
                if (hash_equals($beallitasok['admin']['felhasznalonev'], $felhasznalonev) && password_verify($jelszo, $beallitasok['admin']['jelszo_hash'])) {
                    session_regenerate_id(true); $_SESSION['admin'] = true;
                    header('Location: index.php?page=admin'); exit;
                }
                $hibaUzenet = 'Hibás felhasználónév vagy jelszó.';
            }
        }
        require __DIR__ . '/../Views/admin_login.php';
    }

    public function dashboard(): void
    {
        adminSzukseges();
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['muvelet'] ?? '') === 'torles') {
            if (!csrf_ervenyes($_POST['csrf'] ?? '')) { http_response_code(400); exit('Érvénytelen kérés.'); }
            $azonosito = filter_var($_POST['azonosito'] ?? null, FILTER_VALIDATE_INT);
            if ($azonosito && $azonosito > 0) $this->modell->torol($azonosito);
            header('Location: index.php?page=admin&deleted=1'); exit;
        }
        $jelentkezesek = $this->modell->osszesJelentkezes();
        $statisztikak = $this->modell->statisztikak();
        require __DIR__ . '/../Views/admin.php';
    }

    public function logout(): void
    {
        if (!csrf_ervenyes($_POST['csrf'] ?? '')) { http_response_code(400); exit('Érvénytelen kérés.'); }
        unset($_SESSION['admin']); session_regenerate_id(true);
        header('Location: index.php?page=admin-login'); exit;
    }
}
