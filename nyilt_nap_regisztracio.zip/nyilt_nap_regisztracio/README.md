# Nyílt napi regisztráció – PHP és MySQL

## Telepítés XAMPP-ban
1. Másold a `nyilt_nap_regisztracio` mappát a `C:\xampp\htdocs\` könyvtárba.
2. Indítsd el az Apache és MySQL szolgáltatást.
3. Nyisd meg a phpMyAdmin felületét, és importáld a `database/schema.sql` fájlt. Ez létrehozza a `nyilt_nap` adatbázist, a magyar nevű táblákat és a hat szakot.
4. Ellenőrizd a `config/config.php` adatbázis-kapcsolati beállításait.
5. Nyisd meg: `http://localhost/nyilt_nap_regisztracio/public/`

Admin belépés: `http://localhost/nyilt_nap_regisztracio/public/index.php?page=admin-login`
- Felhasználónév: `admin`
- Kezdeti jelszó: `NyiltNap2026!`

Éles használat előtt változtasd meg az admin jelszóhash-ét a `config/config.php` fájlban.