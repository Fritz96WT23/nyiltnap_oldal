<?php
// Állítsd be a saját XAMPP/MySQL adataidat.
return [
    'adatbazis' => [
        'kiszolgalo' => 'localhost',
        'adatbazis_neve' => 'nyilt_nap',
        'felhasznalo' => 'root',
        'jelszo' => '',
        'karakterkeszlet' => 'utf8mb4',
    ],
    // Első belépés után változtasd meg az admin jelszót!
    'admin' => [
        'felhasznalonev' => 'admin',
        // Alapértelmezett jelszó: NyiltNap2026! (éles használat előtt cseréld le)
        'jelszo_hash' => '$2y$12$4zWzirsi3q6rGdcF5UC4J.zzCtVeRQRCKxoU878KmQZEzFWAjnAoO',
    ],
];
