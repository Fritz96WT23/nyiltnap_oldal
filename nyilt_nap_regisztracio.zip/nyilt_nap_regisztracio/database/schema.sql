CREATE DATABASE IF NOT EXISTS nyilt_nap CHARACTER SET utf8mb4 COLLATE utf8mb4_hungarian_ci;
USE nyilt_nap;

CREATE TABLE IF NOT EXISTS jelentkezesek (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    teljes_nev VARCHAR(160) NOT NULL,
    iskola_neve VARCHAR(200) NOT NULL,
    lakhatasi_forma ENUM('koleszos', 'bejaro') NOT NULL,
    vegzos TINYINT(1) NOT NULL DEFAULT 0,
    letrehozva TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX index_letrehozva (letrehozva),
    INDEX index_vegzos (vegzos),
    INDEX index_lakhatasi_forma (lakhatasi_forma)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS szakok (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nev VARCHAR(160) NOT NULL UNIQUE,
    aktiv TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS jelentkezes_szakok (
    jelentkezes_id INT UNSIGNED NOT NULL,
    szak_id INT UNSIGNED NOT NULL,
    PRIMARY KEY (jelentkezes_id, szak_id),
    CONSTRAINT fk_jelentkezes_szakok_jelentkezes FOREIGN KEY (jelentkezes_id) REFERENCES jelentkezesek(id) ON DELETE CASCADE,
    CONSTRAINT fk_jelentkezes_szakok_szak FOREIGN KEY (szak_id) REFERENCES szakok(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

INSERT IGNORE INTO szakok (nev) VALUES
('Szoftver Fejlesztő és -Tesztelő'),
('Pénzügyi-Számviteli Ügyintéző'),
('Szerszám- és Készülékgyártó'),
('Elektronikai Műszerész'),
('Mechatronikus Karbantartó'),
('CNC-Programozó');
